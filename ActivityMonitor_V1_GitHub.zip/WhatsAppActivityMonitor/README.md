# Activity Monitor V1.0 (Android)

Aplicación de registro **manual** de sesiones asociadas a contactos. Incluye altas de contactos, inicio/finalización de sesiones, historial, duración y almacenamiento local SQLite.

**No accede a WhatsApp, no obtiene estados «en línea» de otras personas, no monitorea contactos automáticamente y no solicita permisos invasivos.** Las sesiones son datos ingresados por quien usa la app.

## Compilación
1. Instalar Android Studio reciente con Android SDK 35 y JDK 17.
2. Abrir esta carpeta como proyecto Android Studio.
3. Esperar la sincronización de Gradle (requiere internet para descargar dependencias).
4. Elegir Build > Build APK(s).
5. Encontrar el archivo generado en `app/build/outputs/apk/debug/app-debug.apk`.

Este paquete contiene **código fuente**, no un APK compilado. No se pudo compilar en el entorno de creación por falta de Android SDK/Gradle.

## Compilar sin computadora

Se incluye el workflow `.github/workflows/build-apk.yml` para GitHub Actions. Consulta `GUIA_DESDE_CELULAR.md` para instrucciones desde Android.
