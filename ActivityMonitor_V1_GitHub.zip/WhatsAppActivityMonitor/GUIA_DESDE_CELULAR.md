# Compilar Activity Monitor desde un celular Android

El proyecto incluye `.github/workflows/build-apk.yml`, que permite generar un APK con GitHub Actions sin computadora.

## Pasos

1. Descarga y descomprime `ActivityMonitor_V1_GitHub.zip` en tu teléfono.
2. En https://github.com crea una cuenta (si aún no tienes) y un repositorio **privado** nuevo, sin archivos iniciales. El plan gratuito normalmente incluye minutos limitados de Actions para repositorios privados.
3. Abre GitHub desde Chrome y activa **Sitio para computadoras** si no aparecen las opciones de carga.
4. Sube **el contenido de la carpeta `WhatsAppActivityMonitor`**, no el ZIP entero, manteniendo las rutas: `app/src/...`, `app/build.gradle.kts`, `build.gradle.kts`, `settings.gradle.kts` y `.github/workflows/build-apk.yml`. La carpeta `.github` puede estar oculta en algunos gestores de archivos; asegúrate de incluirla. GitHub web puede no admitir cargar carpetas en todos los navegadores móviles: si ocurre, usa github.dev (tecla `.` en el repositorio, o abre `https://github.dev/USUARIO/REPOSITORIO`) y arrastra o sube archivos manteniendo sus rutas, o usa una herramienta Git móvil.
5. Guarda los cambios (commit) en la rama `main`.
6. En GitHub abre **Actions → Compilar APK Android → Run workflow** (o espera a que termine la ejecución automática por push).
7. Abre la ejecución terminada. En **Artifacts**, toca **ActivityMonitor-V1-APK** y descarga el ZIP que contiene `app-debug.apk`.
8. Extrae `app-debug.apk` e instálalo. Android puede pedir autorización para instalar aplicaciones desde esa fuente. Instala únicamente archivos que hayas compilado en tu propio repositorio.

**Aviso:** No se ha verificado una compilación real en este entorno. GitHub puede requerir ajustes de cuenta, interfaz o SDK. Esta app registra sesiones manualmente; no obtiene el estado de conexión de WhatsApp ni monitorea a terceros automáticamente.
