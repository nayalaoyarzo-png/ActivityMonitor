package com.example.activitymonitor

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var db: Store
    private lateinit var root: LinearLayout
    private val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale("es", "CL"))
    private val navy = Color.rgb(20, 37, 57)
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db = Store(); render() }
    private fun label(text: String, size: Float = 16f): TextView = TextView(this).apply { this.text=text; textSize=size; setTextColor(navy); setPadding(8,12,8,12) }
    private fun button(text: String, action: () -> Unit): Button = Button(this).apply { this.text=text; setOnClickListener { action() } }
    private fun render() {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,28,22,16); setBackgroundColor(Color.rgb(245,248,251)) }
        setContentView(ScrollView(this).apply { addView(root) })
        root.addView(label("ACTIVITY MONITOR", 25f))
        root.addView(label("Historial manual de actividad · V1.0", 13f))
        root.addView(label("Esta aplicación no detecta conexiones de WhatsApp automáticamente.", 13f))
        root.addView(button("+ Agregar contacto") { addContact() })
        val cursor=db.readableDatabase.rawQuery("SELECT id,name FROM contacts ORDER BY name",null)
        cursor.use { while(it.moveToNext()) { val id=it.getLong(0); val name=it.getString(1)
            root.addView(label("● $name",20f))
            val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL }
            row.addView(button("Iniciar") { start(id) }, LinearLayout.LayoutParams(0,-2,1f))
            row.addView(button("Finalizar") { finish(id) }, LinearLayout.LayoutParams(0,-2,1f))
            row.addView(button("Historial") { history(id,name) }, LinearLayout.LayoutParams(0,-2,1f))
            root.addView(row)
            val active=db.readableDatabase.rawQuery("SELECT started FROM sessions WHERE contact_id=? AND ended IS NULL ORDER BY id DESC LIMIT 1", arrayOf(id.toString()))
            active.use { if(it.moveToFirst()) root.addView(label("Sesión iniciada: ${fmt.format(Date(it.getLong(0)))}",12f)) }
        } }
        if(root.childCount==4) root.addView(label("Agrega tu primer contacto para comenzar."))
    }
    private fun addContact() { val input=EditText(this).apply { hint="Nombre del contacto" }
        AlertDialog.Builder(this).setTitle("Nuevo contacto").setView(input).setNegativeButton("Cancelar",null).setPositiveButton("Guardar") { _,_ ->
            val name=input.text.toString().trim(); if(name.isNotEmpty()) { db.writableDatabase.insert("contacts",null,ContentValues().apply { put("name",name) }); render() }
        }.show() }
    private fun start(id:Long) { val check=db.readableDatabase.rawQuery("SELECT id FROM sessions WHERE contact_id=? AND ended IS NULL",arrayOf(id.toString()))
        val exists=check.use { it.moveToFirst() }; if(exists) { Toast.makeText(this,"Ya hay una sesión activa",Toast.LENGTH_SHORT).show(); return }
        db.writableDatabase.insert("sessions",null,ContentValues().apply { put("contact_id",id); put("started",System.currentTimeMillis()) }); render() }
    private fun finish(id:Long) { db.writableDatabase.execSQL("UPDATE sessions SET ended=? WHERE id=(SELECT id FROM sessions WHERE contact_id=? AND ended IS NULL ORDER BY id DESC LIMIT 1)",arrayOf(System.currentTimeMillis(),id)); render() }
    private fun history(id:Long,name:String) { val items=mutableListOf<String>(); var total=0L
        db.readableDatabase.rawQuery("SELECT started,ended FROM sessions WHERE contact_id=? ORDER BY started DESC",arrayOf(id.toString())).use { c -> while(c.moveToNext()) {
            val start=c.getLong(0); val end=if(c.isNull(1)) null else c.getLong(1)
            if(end!=null) total+=(end-start).coerceAtLeast(0)
            items.add("${fmt.format(Date(start))} → ${end?.let { fmt.format(Date(it)) } ?: "En curso"}\n${end?.let { "Duración: ${(it-start)/60000} min" } ?: "Sin finalizar"}")
        } }
        AlertDialog.Builder(this).setTitle("$name · ${items.size} sesiones · ${total/60000} min").setMessage(items.joinToString("\n\n").ifEmpty { "Sin registros" }).setPositiveButton("Cerrar",null).show() }
    inner class Store: SQLiteOpenHelper(this@MainActivity,"activity.db",null,1) {
        override fun onCreate(db:SQLiteDatabase) { db.execSQL("CREATE TABLE contacts(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL)"); db.execSQL("CREATE TABLE sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,contact_id INTEGER NOT NULL,started INTEGER NOT NULL,ended INTEGER,FOREIGN KEY(contact_id) REFERENCES contacts(id))") }
        override fun onUpgrade(db:SQLiteDatabase,oldVersion:Int,newVersion:Int) {} }
}
